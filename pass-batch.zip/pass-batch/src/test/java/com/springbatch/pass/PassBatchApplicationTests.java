package com.springbatch.pass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
